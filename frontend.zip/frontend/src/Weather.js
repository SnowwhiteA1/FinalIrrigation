import React, { useEffect, useState } from "react";
import axios from "axios";

const Weather = ({ setWillRain }) => {
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(true);
  const [locationError, setLocationError] = useState(null);

  const API_KEY = "e13b35e98c4d9355cc32fd45d04dd9b2";

  useEffect(() => {
    const fetchWeatherByLocation = async (latitude, longitude) => {
      try {
        const response = await axios.get(
          `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${API_KEY}&units=metric`
        );
        setWeather(response.data);
        setLoading(false);

        // Check if the weather condition includes "rain"
        const mainWeather = response.data.weather[0].main.toLowerCase();
        if (mainWeather.includes("rain")) {
          setWillRain(true);
        } else {
          setWillRain(false);
        }
      } catch (error) {
        console.error("Error fetching weather data:", error);
        setLocationError("Failed to fetch weather data.");
        setLoading(false);
      }
    };

    const getLocation = () => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const { latitude, longitude } = position.coords;
            fetchWeatherByLocation(latitude, longitude);
          },
          (error) => {
            console.error("Error getting location:", error);
            setLocationError("Location access denied or unavailable.");
            setLoading(false);
          }
        );
      } else {
        setLocationError("Geolocation is not supported by this browser.");
        setLoading(false);
      }
    };

    getLocation();
  }, [setWillRain]);

  if (loading) return <p>Loading weather...</p>;
  if (locationError) return <p>{locationError}</p>;
  if (!weather) return <p>No weather data available.</p>;

  return (
    <div style={{ border: "1px solid #ccc", padding: "1rem", marginTop: "1rem" }}>
      <h3>Weather in {weather.name}</h3>
      <p><strong>Temperature:</strong> {weather.main.temp}°C</p>
      <p><strong>Condition:</strong> {weather.weather[0].description}</p>
      <p><strong>Rain Status:</strong> {weather.weather[0].main.toLowerCase().includes("rain") ? "🌧️ Rain expected" : "☀️ No rain expected"}</p>
    </div>
  );
};

export default Weather;

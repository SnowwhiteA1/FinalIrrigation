import React, { useState, useEffect } from 'react';
import { CircularProgressbar, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';

import { database, ref, onValue, update } from './firebase'; // Import firebase methods
import './App.css';
import Weather from './Weather';

function App() {
  const [moisture, setMoisture] = useState(null);
  const [pumpStatus, setPumpStatus] = useState(false);
  const [manualControl, setManualControl] = useState(false);
  const [lastIrrigation, setLastIrrigation] = useState(null);
  const [autoMode, setAutoMode] = useState(true);
  const [willRain, setWillRain] = useState(false);

  useEffect(() => {
    const systemRef = ref(database, '/system');

    // Listen to realtime updates from Firebase
    const unsubscribe = onValue(systemRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        setMoisture(data.moisture);
        setPumpStatus(data.pump === 'ON');
        setManualControl(data.auto_mode === false);
        setAutoMode(data.auto_mode);
        if (data.last_irrigation) {
          setLastIrrigation(new Date(data.last_irrigation).toLocaleTimeString());
        }
      }
    });

    // Cleanup listener on unmount
    return () => unsubscribe();
  }, []);

  // Toggle pump manually by updating Firebase directly
  const togglePump = () => {
    const newStatus = pumpStatus ? 'OFF' : 'ON';
    update(ref(database, '/system'), {
      pump: newStatus,
      auto_mode: false,
    }).catch(error => {
      console.error('Error updating pump status:', error);
    });
  };

  // Resume automatic mode by updating moisture value and auto_mode in Firebase
  const resumeAutoMode = () => {
    update(ref(database, '/system'), {
      moisture: moisture || 45,
      auto_mode: true,
    }).catch(error => {
      console.error('Error resuming automatic mode:', error);
    });
  };

  return (
    <div className="dashboard-container">
      <h1 className="dashboard-title">SMART IRRIGATION SYSTEM</h1>
      <div className="dashboard-grid">

        <div className='left-column'>
          <div className="card moisture-card">
            <h3>CURRENT MOISTURE</h3>
            <div className="moisture-display">
              <div className="moisture-circle" style={{ width: 100, height: 100 }}>
                <CircularProgressbar
                  value={moisture || 0}
                  text={`${moisture || 0}%`}
                  styles={buildStyles({
                    textSize: '16px',
                    pathColor: moisture > 30 ? '#4CAF50' : '#F44336',
                    textColor: '#000',
                    trailColor: '#eee',
                  })}
                />
              </div>

              <div className="moisture-status">{moisture !== null ? (moisture < 30 ? 'Dry' : 'Moist') : 'Loading...'}</div>
            </div>
            <div className="timestamp">
              <div>{new Date().toLocaleDateString()}</div>
              <div>{new Date().toLocaleTimeString()}</div>
            </div>
          </div>

          <div className="card-irrigation-history-card">
            <h3>LAST IRRIGATION</h3>
            <div style={{ float: "left" }} className="last-irrigation-time">{lastIrrigation || 'N/A'}</div>
            <div style={{ height: '1px', backgroundColor: 'grey', marginBottom: '20px' }} />
            <div className="moisture-analytics">
              <p><strong>Moisture Analytics</strong></p>
              <img src="/chart-placeholder.png" alt="Analytics Chart" />
            </div>
          </div>
        </div>

        <div className='right-column'>
          <div className="card pump-control-card">
            <h3>PUMP CONTROL</h3>
            <div className="auto-mode-toggle">
              <label>Automatic Mode</label>
              <label className="switch">
                <input type="checkbox" checked={autoMode} onChange={autoMode ? resumeAutoMode : togglePump} />
                <span className="slider"></span>
              </label>
            </div>
            <div className="pump-buttons">
              <button onClick={togglePump}>TURN ON</button>
              <button onClick={togglePump}>TURN OFF</button>
            </div>
          </div>
          <div className="card temperature-card">
            <h3>TEMPERATURE STATUS</h3>
            <Weather setWillRain={setWillRain} />
          </div>

          <div className="card-system-status-card">
            <h3>SYSTEM STATUS</h3>
            <ul className="status-list">
              <li>✅ NodeMCU Connected</li>
              <li>✅ Sensor: OK</li>
              <li>✅ Pump: {pumpStatus ? 'ON' : 'OFF'}</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;

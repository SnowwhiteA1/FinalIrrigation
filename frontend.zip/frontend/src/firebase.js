// firebase.js
import { initializeApp } from "firebase/app";
import { getDatabase, ref, onValue, update } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyCsdvtnNHuFPhf-Cdx33GFpO9-TcRVIutE",
  authDomain: "irrigationsystem-55dfc.firebaseapp.com",
  databaseURL: "https://irrigationsystem-55dfc-default-rtdb.firebaseio.com",
  projectId: "irrigationsystem-55dfc",
  storageBucket: "irrigationsystem-55dfc.firebasestorage.app",
  messagingSenderId: "217084650459",
  appId: "1:217084650459:web:16377dc74714ba21d33dfe",
  measurementId: "G-2PV61Y61QX"
};

const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

export { database, ref, onValue, update };
